export interface CorpCustomer {
    cropName:string;
    industryType:string;
    paidUpCap:number;
}

