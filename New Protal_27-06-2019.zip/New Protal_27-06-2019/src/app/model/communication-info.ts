export interface CommunicationInfo {
  emailId: string;
  mobile: string;
  phone: string;
}
