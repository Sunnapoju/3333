export interface IndCustomer {
    firstName:string;
    middleName:string;
    lastName:string;
    gender:string;
    occupation:string;
    dob:string;
}
