import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from '../services/authenticate.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //username = '9000008029';
  //password = 'NicAgent@123';

  username = '';
  password = '';
  errorMessage = 'Invalid Credentials';
  invalidLogin = false;
  mode = 'determinate';


  private _shown = false;

  constructor(private router: Router, private authenticateService: AuthenticateService) { }

  ngOnInit() {
  }


  login() {
    console.log(this.username);
  


    this.authenticateService.executeJWTAuthenticationService(this.username, this.password)
      .subscribe(
        data => {
          console.log(data)
          //this.router.navigate(['register', this.username])
          this.router.navigate(['products'])
          this.invalidLogin = false
        },
        error => {
          console.log(error)
          this.invalidLogin = true
        }
      )

  }

  resetForm(){
    this.username=null;
    this.password=null;
  }

  

}
