import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CommonServiceService {
common;
  constructor() {
    this.common = new Subject();
   }
}
