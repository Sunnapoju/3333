import { Injectable } from '@angular/core';
import { API_URL } from '../app.constants';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { HttpHeaders, HttpClient } from '@angular/common/http';
import {Address} from '../model/address';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor( private httpClient: HttpClient) { }
  //http://192.168.11.116:7001/PortalDev/customer/getAddressFromPin
  //http://192.168.11.116:7001/PortalDev/customer/getAddressFromPin
private BASE_URL = API_URL;

 private serviceUrl=this.BASE_URL+"customer";
 private pincode="PINCODE_TABLE_QUERY:";
newCustomer;
existCustomer;
   getAddressDetailsByPincode(data): Observable < Address[] > {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      })
    };
    data=this.pincode+data;
    console.log("Service:"+data);
    return this.httpClient.post < Address[] > (this.serviceUrl + '/getAddressFromPin', data, httpOptions);
  }

createCustomer(data){
     
 return this.httpClient.post(this.serviceUrl + '/createCustomer', JSON.stringify(data),  {headers: new HttpHeaders({'Content-Type': 'text/plain'}), responseType: 'text'});
        
}

searchCustomerbyId(data){
const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
 return this.httpClient.post(this.serviceUrl  + '/searchCustomer',data,
        httpOptions);
}


public tempRespObj;
/*async getOccupationAndTitle(tableNames: string) {
    await this.httpClient.post(this.BASE_URL + 'PortalDev/quote/codeTables', tableNames, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response data ', data);
          const tempRespObjArr = data;
          console.log(tempRespObjArr);
         return   this.tempRespObj = tempRespObjArr[0];

        },
        error => {
          console.log('Error', error);
          return "error"
        }
      );
  }*/

  getOccupationAndTitle(tableNames: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
     return this.httpClient.post(this.BASE_URL + 'quote/codeTables', tableNames);
  }
id;
setModalRef(id){
this.id=id;
}
getModalRef(){
  return this.id;
}
setNewCutsomerData(newCust){
this.newCustomer=newCust;
}

getNewCutsomerData(newCust){
return this.newCustomer;
}
setExistCustomer(exstCust){
  
 this.existCustomer=exstCust;
}
getExistCustomer(){

 return this.existCustomer;

}
}
