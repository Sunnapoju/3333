import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import CustConstant from '../../data/customer.json';
import moment from 'moment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import PCConstant from '../../data/pc-constant.json';
import * as _ from 'lodash';
@Component({
  selector: 'app-existing-customer-dialog',
  templateUrl: './existing-customer-dialog.component.html',
  styleUrls: ['./existing-customer-dialog.component.css']
})
export class ExistingCustomerDialogComponent implements OnInit {

  constructor(private customerService:CustomerService,public dialog: MatDialog ) { }

  ngOnInit() {
  }
public custId:string;
public pan:string;
public custName:string;
public custType:string="Individual";
public dateOfBirth:string;
public selectid;
isExistCust=false;
public customersearchJson={
  customerType:"",
  customerCode:"",
  custName:"",
  pan:"",
  dateOfBirth:""

};
public tempcustomersearchJson={
  customerType:"",
  customerCode:"",
  custName:"",
  pan:"",
  dateOfBirth:""

};
public customerSearchResponse;
public customersArr=null;
tempCustIndObj = CustConstant.customerIndObject;
tempCustCorpObj = CustConstant.customerCorpObject;
showCustomerTable=false;
getCusomer(id){
  let custObj: any = _.find(this.customersArr, {
      'customerCode': id
    });
    return custObj;
}
 searchCustomer(event){
   alert(this.dialogRef= this.customerService.getModalRef());
   this.customersearchJson.customerCode=this.custId;
   this.customersearchJson.customerType=this.custType;
   this.customersearchJson.custName=this.custName;
   this.customersearchJson.pan=this.pan;
    this.customersearchJson.dateOfBirth= moment(this.dateOfBirth).format("DD-MM-YYYY");

   this.customerService.searchCustomerbyId(this.customersearchJson).subscribe(result=>{
     this.customerSearchResponse=result;
     this.customersArr=this.customerSearchResponse.Customers;
     this.isExistCust=true;
     console.log(this.customersArr);
     if(this.pan==""){
       this.pan="SDFPL5678L";
     }
     this.showCustomerTable=true;
   },(e) => console.log(e), () => {
            console.log("error");
     });
     
 }


custJson;
 refresh(){
   this.custId="";
   this.pan="";
   this.custName="";
   this.dateOfBirth="";
 }
 dialogRef;
select(id){
  alert(this.selectid);
//this.customerService.setExistCustomer(this.getCusomer(id))
this.dialogRef= this.customerService.getModalRef();
this.custJson=this.getCusomer(this.selectid)
this.tempcustomersearchJson.custName=this.convert(this.custJson.firstName.toLowerCase())+" "+this.convert(this.custJson.lastName.toLowerCase());
this.tempcustomersearchJson.customerCode=this.custJson.customerCode;
this.tempcustomersearchJson.customerType=this.custType.toUpperCase();

this.dialogRef.close(this.tempcustomersearchJson);
//portalServiceInputObj
  
}
 convert(name){
    return name.charAt(0).toUpperCase()+name.slice(1);
  }
  
}
