import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-quote-mci',
  templateUrl: './quick-quote-mci.component.html',
  styleUrls: ['./quick-quote-mci.component.css']
})
export class QuickQuoteMCIComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
