import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuickQuoteMCIComponent } from './quick-quote-mci.component';

describe('QuickQuoteMCIComponent', () => {
  let component: QuickQuoteMCIComponent;
  let fixture: ComponentFixture<QuickQuoteMCIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuickQuoteMCIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickQuoteMCIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
