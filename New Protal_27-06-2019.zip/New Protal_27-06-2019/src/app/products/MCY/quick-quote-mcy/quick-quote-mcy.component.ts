import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-quote-mcy',
  templateUrl: './quick-quote-mcy.component.html',
  styleUrls: ['./quick-quote-mcy.component.css']
})
export class QuickQuoteMCYComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
public dep:any;
}
