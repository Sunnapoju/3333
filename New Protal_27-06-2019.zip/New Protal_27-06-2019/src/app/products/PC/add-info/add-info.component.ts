import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatRadioButton, MatRadioChange } from '@angular/material/radio';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import ADDConstant from '../../../data/add-constant.json';
import { FormGroupDirective } from '@angular/forms';
import { NgForm, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CustomerInfoComponent } from '../../../Customer/customer-info/customer-info.component';


import moment from 'moment';
import { API_URL } from '../../../app.constants';
//import PCConstant from '../../data/pc-constant.json';


@Component({
  selector: 'app-add-info',
  templateUrl: './add-info.component.html',
  styleUrls: ['./add-info.component.css']
})
export class AddInfoComponent implements OnInit {


  selected: any = '';
  public isCustomer = true;
  /* for vehicle acc related declarations code starts here */
  public accessoriesJson = {
    "fieldValueMap": {
      "YearOfMake": "",
      "IManufacturerSellingPrice": "",
      "NIC_FestivalSumInsured_Benefit": "",
      "NIC_Depriciation1": ""
    },
    "interestDescription": "",
    "interestSi": 0,
    "interestType": 1,
    "interestTypeCode": "",
    "policyCtId": ""
  }

  public accessoriesJsonArray: any = [];


  /* for vehicle acc related declarations code ends here*/


  /* for PA named pass related code starts here */

  public PANamedPassDetailsJson = {
    "fieldValueMap": {
      "NICBenefitName": "",
      "NIC_PC_Interest_Age": "",
      "NICBenefitNomineeAge": "",
      "NICBenefitNomineeName": "",
      "NICBennefitRelationship": "",
      "NICBennefitGuardianName": "",
      "NICBennefitGuardianAge": "",
      "NICBennefitGuardianRelWithNominee": "",
      "NICNomineeAddress": ""
    },
    "interestSi": 100000,
    "interestType": 700000301,
    "interestTypeCode": "PA Named"
  }

  public PANamedPassDetailsJsonArray: any = [];

  /* for PA named pass related code ends here */

  json: any = ADDConstant;
  public addinf = "";
  paramsSub: any;
  responseJsonObj1 = {};
  AccessoryObject = ADDConstant.accesorytype;
  FinancialObject = ADDConstant.financialtype;
  NoofyearsObject = ADDConstant.noofyears;
  YearofMfg = ADDConstant.yom;
  csiopted = ADDConstant.csi;
  anyclaimsreported = ADDConstant.anyclaimsrep;
  ncb = ADDConstant.ncb;

  tempPortalServiceInputObj = ADDConstant.portalServiceInputObj;
  tempPolicyBODynObjListArr = ADDConstant.policyBODynObjListArr;
  tDynamicAttributeVOListObj = ADDConstant.dynamicAttributeVOListObj;
  tempInsuredBODynObjListArr = ADDConstant.insuredBODynObjListArr;
  tempInsuredBOFieldValueMap = ADDConstant.insuredBOFieldValueMap;
  tOdPolicyCtSOABOListObj = ADDConstant.odPolicyCtSOABOListObj;
  tOdOdPolicyCtAcceSOABOListObj = ADDConstant.odOdPolicyCtAcceSOABOListObj;
  telecOdPolicyCtAcceSOABOListObj = ADDConstant.elecOdPolicyCtAcceSOABOListObj;
  tpdTpPolicyCtAcceSOABOListObj = ADDConstant.pdTpPolicyCtAcceSOABOListObj;
  totpdTpPolicyCtAcceSOABOListObj = ADDConstant.otpdTpPolicyCtAcceSOABOListObj;
  tTpPolicyCtSOABOListObj = ADDConstant.tpPolicyCtSOABOListObj;
  tTpbiTpPolicyCtAcceSOABOList = ADDConstant.tpbiTpPolicyCtAcceSOABOList;
  tTppdTpPolicyCtSOABOListObj = ADDConstant.tppdTpPolicyCtAcceSOABOListObj;
  tpaPolicyCtSOABOListObj = ADDConstant.paPolicyCtSOABOListObj;

  tcpapaPolicyCtAcceSOABOListObj = ADDConstant.cpapaPolicyCtAcceSOABOListObj;
  topapdpaPolicyCtAcceSOABOListObj = ADDConstant.opapdpaPolicyCtAcceSOABOListObj;
  tpanpaPolicyCtAcceSOABOListObj = ADDConstant.panpaPolicyCtAcceSOABOListObj;
  tpaunpaPolicyCtAcceSOABOListObj = ADDConstant.paunpaPolicyCtAcceSOABOListObj;

  tInvoicePolicyCtSOABOListObj: any;
  tEnginePolicyCtSOABOListObj: any;

  tempPolicySOABO = ADDConstant.policySOABO;
  tempInsuredSOABOListObj = ADDConstant.insuredSOABOListObj;
  tempGenPolicyInfoSOABOObj = ADDConstant.genPolicyInfoSOABOObj;
  tempVehicleInsuredSOABOObj = ADDConstant.vehicleInsuredSOABOObj;
  tempNicPolicyCustSOABOObj = ADDConstant.nicPolicyCustSOABOObj;

  tDiscPolicyDiscSOABOListObj = ADDConstant.discPolicyDiscSOABOListObj;
  tLoadPolicyDiscSOABOListObj = ADDConstant.loadPolicyDiscSOABOListObj;
  tPolicyPaymentSOABOObj = ADDConstant.policyPaymentSOABOObj;
  tpreviousInsuranceSOABOListobj = ADDConstant.previousInsuranceSOABOListobj;

  orginalEffectiveDate: any;
  policyEffectiveDate: any;
  policyExpiryDate: any;
  policyLiabilityExpDate: any;
  commonDateFormat = moment.HTML5_FMT.DATETIME_LOCAL_SECONDS;
  dateFormatAppend = '+05:30';
  vehicleAge: any;
  quickQuoteForm = {
    elecDepr: '',
    engineCover: '2',
    paOwnerDriver: '2',
    invoiceCover: '2',
    dateOfDelPurchase: new Date(),
    yearofmake: new Date(),
    vehicleAccessory: '2',
    financierInterestType: '2',
    legalLiabilitytoEmployees: '2',
    legalLiabilitytoPaiddriver: '2',
    includePersonalAccidentCoverforOwnerDriver: '2',
    includePersonalAccidentCoverforPaidDriverCleanerConductor: '2',
    includePersonalAccidentCoverforNamedPassengers: '2',
    includePersonalAccidentCoverforUnNamedPassengers: '2',
    PrevIns: '2',
    prevpolicyto: new Date(),
    defaultexpDate: '',
    defaultexpliaDate: '',
    defaultEffectDate: new Date() // later get it from UI
  };
  title = 'NIC-Lite';
  responseJsonObj2 = { quoteResult: { app: '', quoteNo: '', autoUwMsg: '', proposalStatus: '' }, saveQuoteIds: { policyId: '', payInfoId: '', insuredId: '', 700000500: '', 700001243: '' } };
  responseJsonObj3 = { quoteResult: { app: '', quoteNo: '', autoUwMsg: '', proposalStatus: '' }, saveQuoteIds: { policyId: '', payInfoId: '', insuredId: '', 700000500: '', 700001243: '' } };
  filterValue: any;
  url = 'http://192.168.11.116:7001/';
  //public url = "http://192.168.11.116:7001/PortalDev/"
  dipObjArr: any;

  onBlurMethod() {

    const mspValue: number = parseInt(this.accessoriesJson.fieldValueMap.IManufacturerSellingPrice);
    const deprValue: number = parseInt(this.quickQuoteForm.elecDepr);
    console.log(deprValue);
    var id1: any = mspValue * (100 - deprValue) / 100;
    this.accessoriesJson.fieldValueMap.NIC_FestivalSumInsured_Benefit = String(id1);
  }

  /* PA owner driver guardian fields fields appearance logic starts here*/
  public displayPAownerDrivGuardFeilds: boolean = false;

  isDisplayPAownerDrivGuardFeilds() {
    const PAOWnerDrivNomAge: number = parseInt(this.tcpapaPolicyCtAcceSOABOListObj.fieldValueMap.NICBenefitNomineeAge);
    console.log("ontab called");
    if (PAOWnerDrivNomAge < 18) {
      this.displayPAownerDrivGuardFeilds = true;
      console.log("string has converted to number");
    }
    else {
      this.displayPAownerDrivGuardFeilds = false;;
    }
  }

  /* PA owner driver guardian fields fields appearance logic ends here*/

  /* PA Named guardian fields fields appearance logic starts here*/
  public displayNamedDrivGuardFeilds: boolean = false;


  isDisplayPANamedDrivGuardFeilds() {
    const PANamedNomAge: number = parseInt(this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeAge);
    console.log("ontab called");
    if (PANamedNomAge < 18) {
      this.displayNamedDrivGuardFeilds = true;
      console.log("string has converted to number");
    }
    else {
      this.displayNamedDrivGuardFeilds = false;;
    }
  }
  /* PA Named guardian fields fields appearance logic ends here*/


  /* Vehicle accesory related code ends here*/
  public showVehAccTable: boolean = false;
  public isDisabled = false;
  public isRefresh = false;
  public isAddOfVehAcc = true;
  public isUpdate = false;
  public currentid;
  public tempAccessoriesJson;
  public i: number = 0;
  addRowsOfVehAcc() {

    if (this.accessoriesJsonArray.length >= 2) {
      this.isAddOfVehAcc = false;
    }
    console.log("add rows method called");
    this.showVehAccTable = true;

    this.tempAccessoriesJson = JSON.stringify(this.accessoriesJson);
    console.log(this.accessoriesJson);
    this.accessoriesJsonArray.push(JSON.parse(this.tempAccessoriesJson));
    console.log(this.accessoriesJsonArray[0].accType);
    console.log(this.accessoriesJsonArray);
    //if you want to clear input
    this.accessoriesJson.interestTypeCode = null;
    this.accessoriesJson.interestDescription = null;
    this.quickQuoteForm.yearofmake = null;
    this.quickQuoteForm.elecDepr = null;
    this.accessoriesJson.fieldValueMap.IManufacturerSellingPrice = null;
    this.accessoriesJson.fieldValueMap.NIC_FestivalSumInsured_Benefit = null;
    ADDConstant.elecOdPolicyCtAcceSOABOListObj = this.accessoriesJsonArray;
    console.log(ADDConstant.elecOdPolicyCtAcceSOABOListObj);
  }

  getinterestTypeCodeId(interestType) {
    let index;
    for (let i = 0; i < this.AccessoryObject.length; i++) {
      if (this.AccessoryObject[i].value == interestType) {
        index = i;
      }
    }
    return index;
  }


  onEditRowOfVehAcc(name) {
    if (this.accessoriesJsonArray.length >= 2) {
      this.isAddOfVehAcc = false;

    }
    this.isAddOfVehAcc = false;
    this.isUpdate = true;
    this.isRefresh = true;
    alert(name);
    this.currentid = this.getId(name, this.accessoriesJsonArray, "interestTypeCode");
    this.isDisabled = true;
    console.log("edit rows method called");
    //if you want to clear input
    this.accessoriesJson.interestTypeCode = this.accessoriesJsonArray[this.currentid].interestTypeCode;
    this.accessoriesJson.interestDescription = this.accessoriesJsonArray[this.currentid].interestDescription;;
    this.quickQuoteForm.yearofmake = new Date(this.accessoriesJsonArray[this.currentid].fieldValueMap.YearOfMake);
    this.quickQuoteForm.elecDepr = this.accessoriesJsonArray[this.currentid].fieldValueMap.NIC_Depriciation1;
    this.accessoriesJson.fieldValueMap.IManufacturerSellingPrice = this.accessoriesJsonArray[this.currentid].fieldValueMap.IManufacturerSellingPrice;
    this.accessoriesJson.fieldValueMap.NIC_FestivalSumInsured_Benefit = this.accessoriesJsonArray[this.currentid].fieldValueMap.NIC_FestivalSumInsured_Benefit;
    ADDConstant.elecOdPolicyCtAcceSOABOListObj = this.accessoriesJsonArray;
    console.log(ADDConstant.elecOdPolicyCtAcceSOABOListObj);
  }

  onRemoveRow(accname) {

    console.log(this.accessoriesJsonArray);
    this.accessoriesJsonArray.splice(this.getId(accname, this.accessoriesJsonArray, "interestTypeCode"), 1);
    if (this.accessoriesJsonArray.length <= 0) {
      this.showVehAccTable = false;
      this.isAddOfVehAcc = true;
    }
    this.isAddOfVehAcc = true;
    console.log(this.accessoriesJsonArray);
    ADDConstant.elecOdPolicyCtAcceSOABOListObj = this.accessoriesJsonArray;
    this.refreshOfVehAcc();
  }

  getId(name, checkarray, checkname) {
    let index;
    for (let i = 0; i < checkarray.length; i++) {
      if (checkarray[i][checkname] == name) {
        index = i;
      }
    }
    return index;
  }
  updateRowOfVehAcc() {
    if (this.accessoriesJsonArray.length >= 2) {
      this.isAddOfVehAcc = false;
    } else {
      this.isAddOfVehAcc = true;
    }
    this.isUpdate = false;
    this.isRefresh = false;

    //fieldValueMap.NIC_FestivalSumInsured_Benefit
    //fieldValueMap.IManufacturerSellingPrice
    //fieldValueMap.NIC_Depriciation1
    //YearOfMake
    this.accessoriesJsonArray[this.currentid].interestTypeCode = this.accessoriesJson.interestTypeCode;
    this.accessoriesJsonArray[this.currentid].interestDescription = this.accessoriesJson.interestDescription;
    this.accessoriesJsonArray[this.currentid].fieldValueMap.YearOfMake = this.quickQuoteForm.yearofmake;
    this.accessoriesJsonArray[this.currentid].fieldValueMap.NIC_Depriciation1 = this.quickQuoteForm.elecDepr;
    this.accessoriesJsonArray[this.currentid].fieldValueMap.IManufacturerSellingPrice = this.accessoriesJson.fieldValueMap.IManufacturerSellingPrice;
    this.accessoriesJsonArray[this.currentid].fieldValueMap.NIC_FestivalSumInsured_Benefit = this.accessoriesJson.fieldValueMap.NIC_FestivalSumInsured_Benefit;
    this.refreshOfVehAcc();
    ADDConstant.elecOdPolicyCtAcceSOABOListObj = this.accessoriesJsonArray;

  }
  refreshOfVehAcc() {
    this.isDisabled = false;

    this.accessoriesJson.interestTypeCode = null;
    this.accessoriesJson.interestDescription = null;
    this.quickQuoteForm.yearofmake = null;
    this.quickQuoteForm.elecDepr = null;
    this.accessoriesJson.fieldValueMap.IManufacturerSellingPrice = null;
    this.accessoriesJson.fieldValueMap.NIC_FestivalSumInsured_Benefit = null;
    if (this.accessoriesJsonArray.length >= 3) {
      this.isAddOfVehAcc = false;
    } else {
      this.isAddOfVehAcc = true;
    }
    this.isUpdate = false;
    this.isRefresh = false;
  }

  /* Vehicle accesory related code ends here*/


  /* PA named pass related code starts here*/

  public showPANamedPassDetailsTable: boolean = false;
  public tempPANamedPassDetailsJson;
  public isAddOfNamed = true;
  public isUpdateOfNamed = false;
  public isRefreshOfNamed = false;
  addRowsOfPaNamed() {

    if (this.PANamedPassDetailsJsonArray.length >= 2) {
      this.isAddOfNamed = false;
    }
    console.log("add rows method of PA named called");
    this.showPANamedPassDetailsTable = true;

    this.tempPANamedPassDetailsJson = JSON.stringify(this.PANamedPassDetailsJson);
    console.log(this.PANamedPassDetailsJson);

    this.PANamedPassDetailsJsonArray.push(JSON.parse(this.tempPANamedPassDetailsJson));


    console.log(this.PANamedPassDetailsJsonArray);

    //if you want to clear input
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NIC_PC_Interest_Age = null;
    // this.PANamedPassDetailsJson.interestSi = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeAge = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitRelationship = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianAge = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianRelWithNominee = null;

    ADDConstant.panpaPolicyCtAcceSOABOListObj = this.PANamedPassDetailsJsonArray;
    console.log(ADDConstant.panpaPolicyCtAcceSOABOListObj);
  }

  public currentIdOfPANamed;
  onEditRowOfPANamed(id) {
    this.isAddOfNamed = false;
    this.isUpdateOfNamed = true;
    this.isRefreshOfNamed = true;
    this.currentIdOfPANamed = id;
    alert(id);

    this.isDisabled = true;
    console.log("edit rows method called");

    //if you want to clear input
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitName = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBenefitName;
    this.PANamedPassDetailsJson.fieldValueMap.NIC_PC_Interest_Age = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NIC_PC_Interest_Age;
    this.PANamedPassDetailsJson.interestSi = this.PANamedPassDetailsJsonArray[id].interestSi;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeName = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBenefitNomineeName;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeAge = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBenefitNomineeAge;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitRelationship = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBennefitRelationship;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianName = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBennefitGuardianName;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianAge = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBennefitGuardianAge;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianRelWithNominee = this.PANamedPassDetailsJsonArray[id].fieldValueMap.NICBennefitGuardianRelWithNominee;

    ADDConstant.panpaPolicyCtAcceSOABOListObj = this.PANamedPassDetailsJsonArray;
    console.log(ADDConstant.panpaPolicyCtAcceSOABOListObj);
  }

  updateRowOfPANamed() {
    alert("update function of pa called");
    this.isAddOfNamed = true;
    this.isUpdateOfNamed = false;
    this.isRefreshOfNamed = false;

    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBenefitName = this.PANamedPassDetailsJson.fieldValueMap.NICBenefitName;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NIC_PC_Interest_Age = this.PANamedPassDetailsJson.fieldValueMap.NIC_PC_Interest_Age;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].interestSi = this.PANamedPassDetailsJson.interestSi;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBenefitNomineeName = this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeName;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBenefitNomineeAge = this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeAge;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBennefitRelationship = this.PANamedPassDetailsJson.fieldValueMap.NICBennefitRelationship;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBennefitGuardianName = this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianName;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBennefitGuardianAge = this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianAge;
    this.PANamedPassDetailsJsonArray[this.currentIdOfPANamed].fieldValueMap.NICBennefitGuardianRelWithNominee = this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianRelWithNominee;
    ADDConstant.panpaPolicyCtAcceSOABOListObj = this.PANamedPassDetailsJsonArray;
    console.log(ADDConstant.panpaPolicyCtAcceSOABOListObj);
    this.refreshOfPANamed()
  }

  refreshOfPANamed() {
    //if you want to clear input
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NIC_PC_Interest_Age = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBenefitNomineeAge = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitRelationship = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianName = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianAge = null;
    this.PANamedPassDetailsJson.fieldValueMap.NICBennefitGuardianRelWithNominee = null;
  }
  onRemoveRowOfPANamed(id) {

    this.PANamedPassDetailsJsonArray.splice(id, 1);
    if (this.PANamedPassDetailsJsonArray.length <= 0) {
      this.showPANamedPassDetailsTable = false;
      this.isAddOfNamed = true;
    } else {
      this.isAddOfVehAcc = true;
    }

    console.log(this.accessoriesJsonArray);
    ADDConstant.elecOdPolicyCtAcceSOABOListObj = this.accessoriesJsonArray;

  }
  /* PA named pass related code ends here*/




  constructor(private httpClient: HttpClient, private activatedRoute: ActivatedRoute, private router: Router) {

    //this.paramsSub = this.activatedRoute.params.subscribe(params => this.addinf =params['quoteNo']);

    let addinfString = sessionStorage.getItem('addinf');
    console.log('addinfString' + addinfString);
    this.responseJsonObj2 = JSON.parse(addinfString);

    //  console.log("object values:" + this.responseJsonObj2.quoteResult.quoteNo);

    let portalformstring = sessionStorage.getItem('portalform');
    this.tempPortalServiceInputObj = JSON.parse(portalformstring);
    // console.log('portalformstring' + this.tempPortalServiceInputObj.policySOABO);
    //  this.setLoadQuoteData(this.tempPortalServiceInputObj.policySOABO);
  }

  ngOnInit() {


    this.preparePolicyexpDates();
    this.tempInsuredSOABOListObj.planId = 700015907;
    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = '0';
    this.onLoadGetCodeTables('FUEL_TYPE_TABLE_QUERY:VEHICLE_BODY_TABLE_QUERY:VEH_COLOR_TABLE_QUERY:DEPRECIATION_TABLE_QUERY:PREV_COMPANY_TABLE_QUERY');


  }


  // Fuel dropdown
  fuelControl = new FormControl();
  fuelFiltered: Observable<any[]>;
  fuelObjArr: any;

  // Fuel
  buildfuelDropdown(tempObjArr: any) {
    this.fuelFiltered = this.fuelControl.valueChanges
      .pipe(
        startWith(''),
        map(tableObj => tableObj ? this._fuelFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _fuelFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.fuelObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }
  displayCommonFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }

  loadFuelCodTab(optionObj: any) {
    if (optionObj) {
      this.tempInsuredBOFieldValueMap.TypeOfFuel = optionObj.id + '';
    }
  }

  loadcolorCodTab(optionObj: any) {
    if (optionObj) {
      this.tempInsuredBOFieldValueMap.VehColor = optionObj.id + '';
    }
  }

  loadbodyCodTab(optionObj: any) {
    if (optionObj) {
      this.tempInsuredBOFieldValueMap.TypeOfBody = optionObj.id + '';
    }
  }
  loadpiCodTab(optionObj: any) {
    if (optionObj) {
      this.tpreviousInsuranceSOABOListobj.prevCompanyName = optionObj.id + '';
      this.getpcbCodTab('PREV_COMPANY_BRANCH_TABLE_QUERY:' + optionObj.id, 'PCB');
    }
  }
  loadpcbCodTab(optionObj: any) {
    if (optionObj) {
      this.tpreviousInsuranceSOABOListobj.companyBranch = optionObj.id + '';
    }
  }


  // color dropdown
  colorControl = new FormControl();
  colorFiltered: Observable<any[]>;
  colorObjArr: any;

  // color
  buildColorDropdown(tempObjArr: any) {
    this.colorFiltered = this.colorControl.valueChanges
      .pipe(
        startWith(''),
        map(tableObj => tableObj ? this._colorFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _colorFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.colorObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }

  // body dropdown
  bodyControl = new FormControl();
  bodyFiltered: Observable<any[]>;
  bodyObjArr: any;

  // body
  buildbodyDropdown(tempObjArr: any) {
    this.bodyFiltered = this.bodyControl.valueChanges
      .pipe(
        startWith(''),
        map(tableObj => tableObj ? this._bodyFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _bodyFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.bodyObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }

  // previousinsurer dropdown
  piControl = new FormControl();
  piFiltered: Observable<any[]>;
  piObjArr: any;

  // previousinsurer
  buildpiDropdown(tempObjArr: any) {
    this.piFiltered = this.piControl.valueChanges
      .pipe(
        startWith(''),
        map(tableObj => tableObj ? this._piFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _piFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.piObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }

  // previouscompanybranch dropdown
  pcbControl = new FormControl();
  pcbFiltered: Observable<any[]>;
  pcbObjArr: any;

  // previousinsurer
  buildpcbDropdown(tempObjArr: any) {
    this.pcbFiltered = this.pcbControl.valueChanges
      .pipe(
        startWith(''),
        map(tableObj => tableObj ? this._pcbFilter(tableObj) : tempObjArr.slice())
      );
  }
  private _pcbFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.pcbObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }

  deprObjArr: any;

  async onLoadGetCodeTables(tableNames: string) {
    await this.httpClient.post(this.url + 'quote/codeTables', tableNames, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response data ', data);
          const tempRespObjArr = data;
          const tempRespObj = tempRespObjArr[0];

          this.fuelObjArr = tempRespObj.FUEL_TYPE_TABLE_QUERY;
          this.buildfuelDropdown(this.fuelObjArr);
          this.colorObjArr = tempRespObj.VEH_COLOR_TABLE_QUERY;
          this.buildColorDropdown(this.colorObjArr);
          this.bodyObjArr = tempRespObj.VEHICLE_BODY_TABLE_QUERY;
          this.buildbodyDropdown(this.bodyObjArr);
          this.bodyObjArr = tempRespObj.VEHICLE_BODY_TABLE_QUERY;
          this.buildbodyDropdown(this.bodyObjArr);
          this.deprObjArr = tempRespObj.DEPRECIATION_TABLE_QUERY;
          this.piObjArr = tempRespObj.PREV_COMPANY_TABLE_QUERY;
          this.buildpiDropdown(this.piObjArr);

        },
        error => {
          console.log('Error', error);
        }
      );
  }

  async getpcbCodTab(tableCodeName: string, fromWhere: string) {
    await this.httpClient.post(this.url + 'quote/codeTableByCode', tableCodeName, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response ddd data ', data);
          if (fromWhere === 'PCB') {
            this.pcbObjArr = data;
            this.buildpcbDropdown(this.pcbObjArr);
          }
        },
        error => {
          console.log('Error', error);
        }
      );
  }

  setPolicyEffectiveDate() {
    this.orginalEffectiveDate = moment(this.quickQuoteForm.defaultEffectDate).format(this.commonDateFormat);
    console.log(this.orginalEffectiveDate);
  }
  preparePolicyDates() {
    this.setPolicyEffectiveDate();
    console.log(this.orginalEffectiveDate);
    this.policyEffectiveDate = this.orginalEffectiveDate + this.dateFormatAppend;
    console.log(this.policyEffectiveDate);
    const effDate = this.quickQuoteForm.defaultEffectDate;
    if (this.tempInsuredSOABOListObj.planId === 700015907) {
      const expiryDate = new Date(effDate.getFullYear() + 1, effDate.getMonth(), effDate.getDate() - 1);
      expiryDate.setHours(23);
      expiryDate.setMinutes(59);
      expiryDate.setSeconds(59);
      const momentExpDate = moment(expiryDate).format(this.commonDateFormat);
      this.policyExpiryDate = momentExpDate + this.dateFormatAppend;
      console.log(this.policyExpiryDate);
      const lExpiryDate = new Date(effDate.getFullYear() + 3, effDate.getMonth(), effDate.getDate() - 1);
      lExpiryDate.setHours(23);
      lExpiryDate.setMinutes(59);
      lExpiryDate.setSeconds(59);
      this.policyLiabilityExpDate = Date.parse(lExpiryDate + '') + '';
      console.log(this.policyLiabilityExpDate);
      this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date = this.policyLiabilityExpDate;
    }
  }

  preparePolicyexpDates() {

    const effDate = this.quickQuoteForm.defaultEffectDate;
    const expiryDate = new Date(effDate.getFullYear() + 1, effDate.getMonth(), effDate.getDate() - 1);
    expiryDate.setHours(23);
    expiryDate.setMinutes(59);
    expiryDate.setSeconds(59);
    const momentExpDate = moment(expiryDate).format(this.commonDateFormat);
    this.policyExpiryDate = momentExpDate + this.dateFormatAppend;
    console.log(this.policyExpiryDate);
    const lExpiryDate = new Date(effDate.getFullYear() + 3, effDate.getMonth(), effDate.getDate() - 1);
    lExpiryDate.setHours(23);
    lExpiryDate.setMinutes(59);
    lExpiryDate.setSeconds(59);
    this.quickQuoteForm.defaultexpDate = momentExpDate;
    this.quickQuoteForm.defaultexpliaDate = moment(lExpiryDate).format(this.commonDateFormat);
    this.policyLiabilityExpDate = Date.parse(lExpiryDate + '') + '';
    console.log(this.policyLiabilityExpDate);
    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date = this.policyLiabilityExpDate;

  }


  prepareVehicleAge() {
    const regDate = this.quickQuoteForm.dateOfDelPurchase;
    console.log(regDate);
    this.vehicleAge = this.getDiffYears(regDate, this.orginalEffectiveDate);
    console.log(this.vehicleAge);
  }
  getIDVAmount(idvResponseArr: any): any {

    const monthDiff = this.getDiffMonths(this.quickQuoteForm.dateOfDelPurchase, this.quickQuoteForm.defaultEffectDate);

    let idvValue: any = 0;
    if (monthDiff <= 6) {
      idvValue = idvResponseArr[0];
    } else if (monthDiff > 6 && monthDiff <= 12) {
      idvValue = idvResponseArr[1];
    } else {
      // needs to cross verify the 10 years
      const vehYear = Math.ceil(monthDiff / 12) + 1; // + one for index
      if (vehYear <= 11) {
        idvValue = idvResponseArr[vehYear];
      }
    }
    return idvValue;
  }

  getIDVmonth(event) {
    const monthDiffy = this.getDiffMonths(this.quickQuoteForm.yearofmake, new Date());
    console.log("yearofmake" + this.quickQuoteForm.yearofmake);
    console.log("new date" + new Date());
    console.log("monthDiffy" + monthDiffy);

    let tempVar: number;
    let tempValue: any;

    if (monthDiffy < 6) {
      tempVar = 1;
      tempValue = 5;
    } else if (monthDiffy >= 6 && monthDiffy < 12) {
      tempVar = 2;
      tempValue = 15;
    }
    else if (monthDiffy >= 12 && monthDiffy < 24) {
      tempVar = 3;
      tempValue = 20;
    }
    else if (monthDiffy >= 24 && monthDiffy < 36) {
      tempVar = 4;
      tempValue = 30;
    }
    else if (monthDiffy >= 36 && monthDiffy < 48) {
      tempVar = 5;
      tempValue = 40;
    }
    else if (monthDiffy >= 48 && monthDiffy < 60) {
      tempVar = 6;
      tempValue = 50;
    }
    else if (monthDiffy >= 60 && monthDiffy < 72) {
      tempVar = 7;
      tempValue = 55;
    }
    else if (monthDiffy >= 72 && monthDiffy < 84) {
      tempVar = 8;
      tempValue = 60;
    } else if (monthDiffy >= 84 && monthDiffy < 96) {
      tempVar = 9;
      tempValue = 65;
    } else if (monthDiffy >= 96 && monthDiffy < 108) {
      tempVar = 10;
      tempValue = 70;
    }

    this.quickQuoteForm.elecDepr = tempValue;
    this.accessoriesJson.fieldValueMap.NIC_Depriciation1 = tempVar + '';
    this.accessoriesJson.fieldValueMap.YearOfMake = this.quickQuoteForm.yearofmake.toString();
    console.log(this.accessoriesJson.fieldValueMap.YearOfMake);

    console.log("this.quickQuoteForm.elecDepr" + this.quickQuoteForm.elecDepr);

  }


  framePortalServiceInput() {

    this.preparePolicyDates(); new Date(1, 1, 2018)
    this.prepareVehicleAge();

    const tempVar: any = this.quickQuoteForm.dateOfDelPurchase;
    const tempVar1: any = this.quickQuoteForm.yearofmake;
    const tempVar2: any = this.quickQuoteForm.prevpolicyto;
    this.tpreviousInsuranceSOABOListobj.policyTo = moment(tempVar2).format(this.commonDateFormat);
    // use this must validate b4 parse here
    this.tempInsuredBOFieldValueMap.DateOfDeliveryPurchase = Date.parse(tempVar) + '';
    this.accessoriesJson.fieldValueMap.YearOfMake = Date.parse(tempVar1) + '';
    console.log(this.accessoriesJson.fieldValueMap.YearOfMake);
    this.tempGenPolicyInfoSOABOObj.marineServiceTaxFlag = 0;

    // this.tempInsuredBOFieldValueMap.YearOfManufacture = this.datePipe.transform(this.tempVar, 'yyyy') + '';
    this.tempVehicleInsuredSOABOObj.registrationNumber = this.tempVehicleInsuredSOABOObj.vehicleRegisterNo;


    this.tOdPolicyCtSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;
    this.tOdPolicyCtSOABOListObj.policyCtId = this.responseJsonObj2.saveQuoteIds.policyId;

    // basic mandatory benefit
    this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
    this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tOdOdPolicyCtAcceSOABOListObj);

    //   this.telecOdPolicyCtAcceSOABOListObj = this.vehAccDetailsArray;


    if (this.quickQuoteForm.vehicleAccessory === "1") {

      this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.telecOdPolicyCtAcceSOABOListObj);
    }
    // push into cover
    this.tempInsuredSOABOListObj.policyCtSOABOList = [];
    this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tOdPolicyCtSOABOListObj);

    this.tTpPolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
    this.tTpPolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
    this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
    this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTpbiTpPolicyCtAcceSOABOList);
    this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTppdTpPolicyCtSOABOListObj);



    if (this.quickQuoteForm.legalLiabilitytoEmployees === "1") {
      console.log(this.totpdTpPolicyCtAcceSOABOListObj.fieldValueMap.NICBenefitNoOfEmployees);
      this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.totpdTpPolicyCtAcceSOABOListObj);
    }

    if (this.quickQuoteForm.legalLiabilitytoPaiddriver === "1") {
      console.log(this.tpdTpPolicyCtAcceSOABOListObj.fieldValueMap.NICBenefitPaidDriver);
      this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tpdTpPolicyCtAcceSOABOListObj);
    }
    this.tpaPolicyCtSOABOListObj.policyCtAcceSOABOList = [];

    if (this.quickQuoteForm.includePersonalAccidentCoverforOwnerDriver === "1") {
      console.log(this.tcpapaPolicyCtAcceSOABOListObj.fieldValueMap.NICBenefitNomineeAge);
      this.tpaPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tcpapaPolicyCtAcceSOABOListObj);
    }

    if (this.quickQuoteForm.includePersonalAccidentCoverforPaidDriverCleanerConductor === "1") {
      console.log(this.topapdpaPolicyCtAcceSOABOListObj.fieldValueMap.NoOfQualifiedPersions);
      this.tpaPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.topapdpaPolicyCtAcceSOABOListObj);
    }

    if (this.quickQuoteForm.includePersonalAccidentCoverforNamedPassengers === "1") {
      // console.log(this.tpanpaPolicyCtAcceSOABOListObj.fieldValueMap.NICBenefitNomineeName);
      this.tpaPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tpanpaPolicyCtAcceSOABOListObj);
    }

    if (this.quickQuoteForm.includePersonalAccidentCoverforUnNamedPassengers === "1") {
      console.log(this.tpaunpaPolicyCtAcceSOABOListObj.fieldValueMap.NoOfQualifiedPersions);
      this.tpaPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tpaunpaPolicyCtAcceSOABOListObj);
    }


    // push into cover
    this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tTpPolicyCtSOABOListObj);
    this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tpaPolicyCtSOABOListObj);
    // option covers
    if (this.quickQuoteForm.invoiceCover === '1') {
      this.tInvoicePolicyCtSOABOListObj = ADDConstant.invoicePolicyCtSOABOListObj;
      this.tInvoicePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
      this.tInvoicePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
      this.tInvoicePolicyCtSOABOListObj.fieldValueMap.BasicIDV = this.tOdOdPolicyCtAcceSOABOListObj.interestSi;
      // push into cover
      this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tInvoicePolicyCtSOABOListObj);
    }
    if (this.quickQuoteForm.engineCover === '1') {
      this.tEnginePolicyCtSOABOListObj = ADDConstant.enginePolicyCtSOABOListObj;
      this.tEnginePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
      this.tEnginePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
      // here needs to set age of vehicle in agreed field
      this.tEnginePolicyCtSOABOListObj.fieldValueMap.AgreedValue = this.vehicleAge + '';
      // push into cover
      this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tEnginePolicyCtSOABOListObj);
    }

    this.tempInsuredSOABOListObj.effectiveDate = this.policyEffectiveDate;
    this.tempInsuredSOABOListObj.expiryDate = this.policyExpiryDate;
    this.tempInsuredSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
    this.tempInsuredSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;
    this.tempInsuredSOABOListObj.vehicleInsuredSOABO = this.tempVehicleInsuredSOABOObj;
    this.tempInsuredSOABOListObj.dynamicObjectList = this.tempInsuredBODynObjListArr;
    this.tempInsuredSOABOListObj.fieldValueMap = this.tempInsuredBOFieldValueMap;

    this.tempPolicySOABO.effectDate = this.policyEffectiveDate;
    this.tempPolicySOABO.expiryDate = this.policyExpiryDate;

    this.tempPolicySOABO.quotationNumber = this.responseJsonObj2.quoteResult.quoteNo;
    this.tempPolicySOABO.proposalStatus = this.responseJsonObj2.quoteResult.proposalStatus;
    this.tempPolicySOABO.policyId = this.responseJsonObj2.saveQuoteIds.policyId;

    if (this.quickQuoteForm.financierInterestType === "1") {
      this.tempPolicyBODynObjListArr[0].dynamicAttributeVOList.push(this.tDynamicAttributeVOListObj);
    }
    this.tempPolicySOABO.dynamicObjectList = this.tempPolicyBODynObjListArr;
    this.tempGenPolicyInfoSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;

    this.tempPolicySOABO.genPolicyInfoSOABO = this.tempGenPolicyInfoSOABOObj;
    this.tempPolicySOABO.insuredSOABOList = [];
    this.tempPolicySOABO.insuredSOABOList.push(this.tempInsuredSOABOListObj);
    this.tempNicPolicyCustSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
    this.tempPolicySOABO.nicPolicyCustSOABO = this.tempNicPolicyCustSOABOObj;
    this.tempPolicySOABO.policyDiscSOABOList = [];
    this.tDiscPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;

    this.tempPolicySOABO.policyDiscSOABOList.push(this.tDiscPolicyDiscSOABOListObj);
    this.tLoadPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
    this.tempPolicySOABO.policyDiscSOABOList.push(this.tLoadPolicyDiscSOABOListObj);
    this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].payInfoId = this.responseJsonObj2.saveQuoteIds.payInfoId;

    this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].policyId = this.responseJsonObj2.saveQuoteIds.policyId;
    this.tempPolicySOABO.policyPaymentSOABO = this.tPolicyPaymentSOABOObj;
    this.tempPolicySOABO.previousInsuranceSOABOList.push(this.tpreviousInsuranceSOABOListobj);

    this.tempPortalServiceInputObj.policySOABO = this.tempPolicySOABO;
    console.log('Final Prepared Object :  ', this.tempPortalServiceInputObj);
  }

  setLoadQuoteData(loadQObj: any) {
    console.log('responseJsonObj1.quoteNo', loadQObj);
    this.tempGenPolicyInfoSOABOObj = loadQObj.genPolicyInfoSOABO;
    console.log(this.tempGenPolicyInfoSOABOObj);
    this.tempVehicleInsuredSOABOObj = loadQObj.insuredSOABOList[0].vehicleInsuredSOABO;
    //this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;
    this.tempNicPolicyCustSOABOObj = loadQObj.nicPolicyCustSOABO;
    this.tPolicyPaymentSOABOObj = loadQObj.policyPaymentSOABO;

    // iterate the discount list and set into appropriate discount type object...
    let tempList = loadQObj.policyDiscSOABOList;
    for (let discObj of tempList) {
      if (discObj.discountType === "105") {
        this.tDiscPolicyDiscSOABOListObj = discObj;
      } else if (discObj.discountType === "91") {
        this.tLoadPolicyDiscSOABOListObj = discObj;
      }
    }
    this.tempInsuredSOABOListObj = loadQObj.insuredSOABOList[0];
    console.log(this.tempInsuredSOABOListObj);

    this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;

    tempList = this.tempInsuredSOABOListObj.policyCtSOABOList;

    for (let ctObj of tempList) {
      if (ctObj.coverType === 700000500) {
        this.tOdPolicyCtSOABOListObj = ctObj;
      } else if (ctObj.coverType === 700001243) {
        this.tTpPolicyCtSOABOListObj = ctObj;
      }
    }

    tempList = this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList;

    for (let ctAccObj of tempList) {
      if (ctAccObj.interestType === 700000120) {
        this.tOdOdPolicyCtAcceSOABOListObj = ctAccObj;
      } else if (ctAccObj.interestType === 100000060) {
        this.telecOdPolicyCtAcceSOABOListObj = ctAccObj;
      }
    }

    tempList = this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList;

    for (let ctAccObj of tempList) {
      if (ctAccObj.interestType === 100000040) {
        this.tTpbiTpPolicyCtAcceSOABOList = ctAccObj;
      } else if (ctAccObj.interestType === 100000041) {
        this.tTppdTpPolicyCtSOABOListObj = ctAccObj;
      }
    }

  }
  // all date convertion methods
  getDiffDays(startdate: Date, enddate: Date): any {
    // define moments for the startdate and enddate
    const startdateMoment = moment(startdate);
    const enddateMoment = moment(enddate);
    if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
      // getting the difference in days
      return enddateMoment.diff(startdateMoment, 'days');
    }
    return undefined;
  }
  getDiffMonths(startdate: Date, enddate: Date): any {
    // define moments for the startdate and enddate
    const startdateMoment = moment(startdate);
    const enddateMoment = moment(enddate);
    if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
      // const years = enddateMoment.diff(startdateMoment, 'years');
      // getting the difference in months
      // console.log("years---"+years);
      //  console.log("metods---"+enddateMoment.diff(startdateMoment, 'months'));
      return enddateMoment.diff(startdateMoment, 'months');
    }
    return undefined;
  }
  getDiffYears(startdate: Date, enddate: Date): any {
    // define moments for the startdate and enddate
    const startdateMoment = moment(startdate);
    const enddateMoment = moment(enddate);
    if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
      // getting the difference in years
      return enddateMoment.diff(startdateMoment, 'years');
    }
    return undefined;
  }
  dateDiff(startdate: Date, enddate: Date): any {
    // define moments for the startdate and enddate
    const startdateMoment = moment(startdate);
    const enddateMoment = moment(enddate);

    if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
      // getting the difference in years
      const years = enddateMoment.diff(startdateMoment, 'years');
      // moment returns the total months between the two dates, subtracting the years
      const months = enddateMoment.diff(startdateMoment, 'months') - (years * 12);
      // to calculate the days, first get the previous month and then subtract it
      startdateMoment.add(years, 'years').add(months, 'months');
      const days = enddateMoment.diff(startdateMoment, 'days');
      console.log(years + ' months ' + months + ' days ' + days);
    }
  }

  saveQuickQuote() {

    console.log('success');

    this.framePortalServiceInput();
    this.httpClient.post(this.url + 'quote/saveQuote',
      JSON.stringify(this.tempPortalServiceInputObj),
      { responseType: 'json' })
      .subscribe(
        data => {
          console.log('POST Request is successful ', data);

          const responseJson = data[0];
          this.responseJsonObj3 = JSON.parse(responseJson);
          console.log('this.responseJsonObj3 ', this.responseJsonObj3);
        },
        error => {
          console.log('Error', error);
        }
      );

  }

  loadQuoteByQuote() {

    console.log('inside load ', this.addinf);
    this.httpClient.post(this.url + 'quote/loadQuote', this.addinf, { responseType: 'json' })
      .subscribe(
        data => {
          console.log('POST Request is successful ', data);

          const responseJson2 = data[0];
          this.responseJsonObj1 = JSON.parse(responseJson2);
          this.setLoadQuoteData(this.responseJsonObj1);

        },
        error => {
          console.log('Error', error);
        }
      );
  }

  public show1: boolean = false;
  public show2: boolean = false;
  public show3: boolean = false;
  public show4: boolean = false;
  public show5: boolean = false;
  public show6: boolean = false;
  public show7: boolean = false;
  public show8: boolean = false;
  public show9: boolean = false;
  public show10: boolean = false;


  vehicleAccessory: number = 0;

  vehAcc(value) {
    if (value.checked == true) {
      this.vehicleAccessory = 1;
      this.quickQuoteForm.vehicleAccessory = '1';
      this.show1 = true;
    } else {
      this.vehicleAccessory = 0;
      this.quickQuoteForm.vehicleAccessory = '0';
      this.show1 = false;
    }
  }

  financierInterestType: number = 0;
  FIA(value) {
    if (value.checked == true) {
      this.financierInterestType = 1;
      this.quickQuoteForm.financierInterestType = '1';
      this.show2 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.financierInterestType = '0';
      this.show2 = false;
    }
  }
  AutomobileAssociationMembership: number = 0;
  AAM(value) {
    if (value.checked == true) {
      this.tempInsuredBOFieldValueMap.AutomobileAssociationMembership = '1';
      this.show3 = true;
    } else {
      this.tempInsuredBOFieldValueMap.AutomobileAssociationMembership = '0';
      this.show3 = false;
    }
  }
  legalLiabilitytoEmployees: number = 0;
  LLE(value) {
    if (value.checked == true) {
      this.legalLiabilitytoEmployees = 1;
      this.quickQuoteForm.legalLiabilitytoEmployees = '1';
      this.show4 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.legalLiabilitytoEmployees = '0';
      this.show4 = false;
    }
  }

  legalLiabilitytoPaiddriver: number = 0;
  LLP(value) {
    if (value.checked == true) {
      this.legalLiabilitytoPaiddriver = 1;
      this.quickQuoteForm.legalLiabilitytoPaiddriver = '1';
      this.show5 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.legalLiabilitytoPaiddriver = '0';
      this.show5 = false;
    }
  }

  includePersonalAccidentCoverforOwnerDriver: number = 0;
  PAC(value) {
    if (value.checked == true) {
      this.includePersonalAccidentCoverforOwnerDriver = 1;
      this.quickQuoteForm.includePersonalAccidentCoverforOwnerDriver = '1';
      this.show6 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.includePersonalAccidentCoverforOwnerDriver = '0';
      this.show6 = false;
    }
  }

  includePersonalAccidentCoverforPaidDriverCleanerConductor: number = 0;
  PACP(value) {
    if (value.checked == true) {
      this.includePersonalAccidentCoverforPaidDriverCleanerConductor = 1;
      this.quickQuoteForm.includePersonalAccidentCoverforPaidDriverCleanerConductor = '1';
      this.show7 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.includePersonalAccidentCoverforPaidDriverCleanerConductor = '0';
      this.show7 = false;
    }
  }


  includePersonalAccidentCoverforNamedPassengers: number = 0;

  PACPNP(value) {
    if (value.checked == true) {
      this.includePersonalAccidentCoverforNamedPassengers = 1;
      this.quickQuoteForm.includePersonalAccidentCoverforNamedPassengers = '1';
      this.show8 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.includePersonalAccidentCoverforNamedPassengers = '0';
      this.show8 = false;
    }
  }


  includePersonalAccidentCoverforUnNamedPassengers: number = 0;
  PACUNP(value) {
    if (value.checked == true) {
      this.includePersonalAccidentCoverforUnNamedPassengers = 1;
      this.quickQuoteForm.includePersonalAccidentCoverforUnNamedPassengers = '1';
      this.show9 = true;
    } else {
      this.financierInterestType = 0;
      this.quickQuoteForm.includePersonalAccidentCoverforUnNamedPassengers = '0';
      this.show9 = false;
    }
  }

  PrevIns: number = 0;

  PIF(value) {
    if (value.checked == true) {
      this.PrevIns = 1;
      this.quickQuoteForm.PrevIns = '1';
      this.show10 = true;
    } else {
      this.PrevIns = 0;
      this.quickQuoteForm.PrevIns = '0';
      this.show10 = false;
    }
  }
}