import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import CustConstant from '../data/customer.json';
import moment from 'moment';
import { HttpClient } from '@angular/common/http';
import { API_URL } from './../app.constants';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';



export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {


  tempIP=API_URL;
  filterValue: any;

  //occupation dropdown
  occupationControl = new FormControl();
  occuFiltered: Observable<any[]>;
  occuObjArr: any;
  
  buildOccupationDropdown(tempObjArr: any) {
    this.occuFiltered = this.occupationControl.valueChanges
      .pipe(startWith(''),
        map(tableObj => tableObj ? this._occupationFilter(tableObj) : tempObjArr.slice())
      );
  }

  private _occupationFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.occuObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }



  //occupation dropdown
  titleControl = new FormControl();
  titleFiltered: Observable<any[]>;
  titleObjArr: any;
  
  buildTitleDropdown(tempObjArr: any) {
    this.titleFiltered = this.titleControl.valueChanges
      .pipe(startWith(''),
        map(tableObj => tableObj ? this._titleFilter(tableObj) : tempObjArr.slice())
      );
  }

  private _titleFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.titleObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }



  async onLoadGetCodeTables(tableNames: string) {
    await this.httpClient.post(this.tempIP + 'quote/codeTables', tableNames, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response data ', data);
          const tempRespObjArr = data;
          const tempRespObj = tempRespObjArr[0];

          this.occuObjArr = tempRespObj.OCCUPATION_TABLE_QUERY;
          this.buildOccupationDropdown(this.occuObjArr);
          

        },
        error => {
          console.log('Error', error);
        }
      );
  }


  displayCommonFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }



  customerType: string;
  buildingName: string;
  streetName: string;
  pincode: string;
  district: string;
  city: string;
  state: string;
  locality: string;
  country: string;


  emailId: string;
  mobile: string;
  phone: string;

  api_url = API_URL;

  tempCustIndObj = CustConstant.customerIndObject;
  tempCustCorpObj = CustConstant.customerCorpObject;

  new = false;
  existing = false;
  customerStatus = '';


  responseJsonObj = { app: '', quoteNo: '', autoUwMsg: '' };

  ngOnInit() {
    //this.onLoadGetCodeTables('OCCUPATION_TABLE_QUERY:TITLE_TABLE_QUERY');
    this.onLoadGetCodeTables('OCCUPATION_TABLE_QUERY');
   }

  constructor(public dialog: MatDialog, private httpClient: HttpClient) { }

  createCustomer() {
    
    this.tempCustIndObj.dateOfBirth = moment(this.tempCustIndObj.dateOfBirth).format("DD-MM-YYYY");

    console.log(JSON.stringify(this.tempCustIndObj));
    console.log(JSON.stringify(this.tempCustCorpObj));
    if (this.customerType == "Individual") {
      this.tempCustIndObj.customerType = this.customerType;
      /*this.tempCustIndObj.address = this.buildingName + "," + this.locality;
      this.tempCustIndObj.primaryEmail = this.emailId;
      this.tempCustIndObj.mobileNo = this.mobile;
      this.tempCustIndObj.telephoneNumber = this.phone;*/
      this.httpClient.post(this.api_url + 'createustomer',
        JSON.stringify(this.tempCustIndObj),
        { responseType: 'json' })
        .subscribe(
          data => {
            console.log('POST Request is successful ', data);

            const responseJson = data[0];
            this.responseJsonObj = JSON.parse(responseJson);
          },
          error => {
            console.log('Error', error);
          }
        );

    } else if (this.customerType == "Corporate") {
     /* this.tempCustCorpObj.pinCd = this.pincode;
      this.tempCustCorpObj.address = this.buildingName + "," + this.locality;
      this.tempCustCorpObj.districtName=this.district;
      this.tempCustCorpObj.stateName = this.state;
      this.tempCustCorpObj.cityName = this.country;
      this.tempCustCorpObj.mobileNo=this.mobile;*/


      this.httpClient.post(this.api_url + 'createCustomer',
        JSON.stringify(this.tempCustCorpObj),
        { responseType: 'json' })
        .subscribe(
          data => {
            console.log('POST Request is successful ', data);

            const responseJson = data[0];
            this.responseJsonObj = JSON.parse(responseJson);
          },
          error => {
            console.log('Error', error);
          }
        );
      
    }




  }







  animal: string;
  name: string;



  openDialog(): void {
    const dialogRef = this.dialog.open(CustomerSearchDialog, {
      //width: '400px',
      //data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }



}
@Component({
  selector: 'customer-search-dialog',
  templateUrl: 'customer-search-dialog.html',
})
export class CustomerSearchDialog {

  search = false;
  constructor(
    public dialogRef: MatDialogRef<CustomerSearchDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  searchCustomer() {
    this.search = true;
  }


}