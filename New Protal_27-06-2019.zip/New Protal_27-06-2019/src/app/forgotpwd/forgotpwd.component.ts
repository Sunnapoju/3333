import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { ActivatedRoute } from "@angular/router";
import { ForgotpasswordService } from '../services/forgotpassword.service';
import { isUndefined } from 'util';
import { isNull } from '@angular/compiler/src/output/output_ast';
import { AgentContact } from '../model/agentContact';

@Component({
  selector: 'app-forgotpwd',
  templateUrl: './forgotpwd.component.html',
  styleUrls: ['./forgotpwd.component.css']
})
export class ForgotpwdComponent implements OnInit {


  username = '';
  email = '';
  mobile = '';

  public agentcontactArr: AgentContact[] = null;
  public agentContact: AgentContact = null;


  invalidAgent = false;
  errorMessage = '';

  responseSuccess=false;

  submitted = false;

message:string;


  constructor(private route: ActivatedRoute,
    private router: Router, private searchAgentService: ForgotpasswordService) {

    this.route.params.subscribe(params => console.log(params));

  }
  ngOnInit() {
  }



  generateTempPassword() {
    this.searchAgentService.resetPassword(this.username)
    .subscribe(
      data => {
      
        console.log(data);
        let response=data;
        console.log(response);
        if (response==="success") {
          this.responseSuccess=true;
          this.message="Recovery password generated and send to your registered mobile number and email id";

        } else if(response==="No data") {
         // this.invalidAgent = true;
          this.message = "Password regeneration failed";
        }
      },
      error => {
        console.log(error)
        this.responseSuccess = true;
        this.message = "Recovery password generated and send to your registered mobile number and email id";

      }
    )
  }


  searchAgent() {

    this.errorMessage = "";
    this.invalidAgent = false;
    this.submitted=false;
    this.message="";
    this.responseSuccess=false;
    this.searchAgentService.searchAgentService(this.username)
      .subscribe(
        data => {
          this.agentcontactArr = <AgentContact[]>(data);
          this.agentContact = this.agentcontactArr[0];
          console.log(this.agentContact);

          if (this.agentContact != null) {
            this.submitted = true;
            this.email = this.agentContact.email_id;
            this.mobile = this.agentContact.phone_no;
            this.username = this.agentContact.agent_id;

          } else {
            this.invalidAgent = true;
            this.errorMessage = "Agent Details not found";
          }






        },
        error => {
          console.log(error)
          this.invalidAgent = true;
          this.errorMessage = "Agent Details not found";

        }
      )
  }
}


